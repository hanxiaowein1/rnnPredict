#include "SlideQualityCheck.h"

SlideQualityCheck::SlideQualityCheck()
{
	
}

SlideQualityCheck::SlideQualityCheck(MultiImageRead& mImgRead)
{

}

SlideQualityCheck::~SlideQualityCheck()
{

}
